/**
* @type {import('vite').UserConfig}
*/
export default {
  build: {
    sourcemap: true
  }
}